from django.apps import AppConfig


class PizzaorderingConfig(AppConfig):
    name = 'PizzaOrdering'
